//package Experiment.Exp4.exp01;
//
//public class IceBox extends ElectricalAppliance {
//    int hasnum = 0;
//
//    public IceBox(String name, int capacity) {
//        super(name, capacity);
//
//    }
//
//
//}
