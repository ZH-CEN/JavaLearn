//package Experiment.Exp4.exp01;
//
//public class MicroWaveOven extends ElectricalAppliance {
//    private boolean status = false;
//
//    public MicroWaveOven(String name, int capacity) {
//        super(name, capacity);
//    }
//
//
//}
