//package Experiment.Exp4.exp01;
//
//public class WashMachine extends ElectricalAppliance{
//    private boolean status = false;
//    public WashMachine(String name, int capacity) {
//        super(name, capacity);
//
//    }
//
//}
