package Experiment.Exp5_6;

public class FloorFan extends ElecticalAppliance {
    private final char type = 'A';
    private double rate;

    FloorFan(int number, String deviceName) {
        super(deviceName);
        this.number = number;
        this.R = 20; // 落地扇的电阻为20
    }

    public void display() {
        System.out.println("@" + this.type + this.number + ":" + (int) this.rate);
    }

    void setRate() {
        double voltagediff = getVoltageDiff();

        if (voltagediff < 80) {
            this.rate = 0;
        } else if (voltagediff < 100) {
            this.rate = 80;
        } else if (voltagediff < 120) {
            this.rate = 160;
        } else if (voltagediff < 140) {
            this.rate = 260;
        } else {
            this.rate = 360;
        }
    }

    @Override
    public void run(double voltage) {
        setVoltage(0, voltage);
        setVoltage(1, 0);
        setRate(); // 设置转速, 使本设备运行
        display();
        for (ElecticalAppliance child : this.children) {
            child.run(0); //TODO:
        }
    }
}