package Experiment.Exp5_6;

abstract public class Lamp extends ElecticalAppliance {
    protected double lightBrightness;

    Lamp(String deviceName) {
        super(deviceName);
    }

    abstract void setLightBrightness();

}
