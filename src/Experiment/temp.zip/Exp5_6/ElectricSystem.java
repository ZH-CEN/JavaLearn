package Experiment.Exp5_6;

public class ElectricSystem {

}
