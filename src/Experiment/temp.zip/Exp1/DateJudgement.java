package Experiment.Exp1;

public class DateJudgement {
    public static void main(String[] args) {

    }
}

enum Date {
    Date()
}
