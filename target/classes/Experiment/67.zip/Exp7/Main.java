package Experiment.Exp7;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

abstract class Animal implements Comparable<Animal> {
    protected String name;
    protected int weight;
    protected int creationOrder;

    public Animal(String name, int weight, int creationOrder) {
        this.name = name;
        this.weight = weight;
        this.creationOrder = creationOrder;
    }

    public abstract void call();

    public String getInfo() {
        return "名字: " + name + ", 体重: " + weight;
    }

    @Override
    public int compareTo(Animal other) {
        return Integer.compare(this.weight, other.weight);
    }
}

class Elephant extends Animal {
    public Elephant(String name, int weight, int creationOrder) {
        super(name, weight, creationOrder);
    }

    @Override
    public void call() {
        System.out.println("象叫声：嘟嘟");
    }
}

class Lion extends Animal {
    public Lion(String name, int weight, int creationOrder) {
        super(name, weight, creationOrder);
    }

    @Override
    public void call() {
        System.out.println("狮吼声：嗷嗷");
    }
}

class Tiger extends Animal {
    public Tiger(String name, int weight, int creationOrder) {
        super(name, weight, creationOrder);
    }

    @Override
    public void call() {
        System.out.println("虎啸声：吼吼");
    }
}

abstract class Appliance {
    protected String name;
    protected int capacity;
    protected List<Animal> animals;

    public Appliance(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.animals = new ArrayList<>();
    }

    public void addAnimal(Animal animal) {
        if (animals.size() < capacity) {
            animals.add(animal);
        } else {
            System.out.println(name + " 已满，无法容纳更多动物");
        }
    }

    public void showAnimals() {
        System.out.println(name + " 内部动物：");
        animals.forEach(a -> System.out.println(a.getInfo()));
    }
}

class Refrigerator extends Appliance {
    public Refrigerator(String name, int capacity) {
        super(name, capacity);
    }
}

class Microwave extends Appliance {
    public Microwave(String name, int capacity) {
        super(name, capacity);
    }
}

class WashingMachine extends Appliance {
    public WashingMachine(String name, int capacity) {
        super(name, capacity);
    }
}
class RandomUtils {
    public static int getRandomInt(int min, int max) {
        return (int) (Math.random() * (max - min + 1)) + min;
    }

    public static Animal getRandomAnimal(int creationOrder) {
        int type = getRandomInt(0, 2);
        int weight = getRandomInt(50, 2000); // 体重范围为 50-2000
        return switch (type) {
            case 0 -> new Elephant("大象" + creationOrder, weight, creationOrder);
            case 1 -> new Lion("狮子" + creationOrder, weight, creationOrder);
            default -> new Tiger("老虎" + creationOrder, weight, creationOrder);
        };
    }
}



public class Main {
    public static void main(String[] args) {
        int counts = 0; // 初始化动物数量
        List<Appliance> elecList = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        // 初始化电器
        System.out.println("请输入第一个电器的名字和容量：");
        String name = scanner.next();
        int cap = scanner.nextInt();
        elecList.add(new Refrigerator(name, cap));

        System.out.println("请输入第二个电器的名字和容量：");
        name = scanner.next();
        cap = scanner.nextInt();
        elecList.add(new Microwave(name, cap));

        System.out.println("请输入第三个电器的名字和容量：");
        name = scanner.next();
        cap = scanner.nextInt();
        elecList.add(new WashingMachine(name, cap));

        System.out.println("请输入要生成的动物数量：");
        counts = scanner.nextInt();

        // 随机生成动物并将其放入电器
        for (int i = 0; i < counts; i++) {
            Animal animal = null;
            int animalType = (int) (Math.random() * 3); // 随机生成动物类型
            int weight = (int) (Math.random() * 2000); // 随机生成动物体重
            int creationOrder = i + 1;

            // 根据类型生成动物对象
            switch (animalType) {
                case 0 -> animal = new Elephant("大象" + creationOrder, weight, creationOrder);
                case 1 -> animal = new Lion("狮子" + creationOrder, weight, creationOrder);
                case 2 -> animal = new Tiger("老虎" + creationOrder, weight, creationOrder);
            }

            // 确保动物不为空，随机选择一个电器让动物进入
            if (animal != null) {
                int elecIndex = (int) (Math.random() * elecList.size());
                elecList.get(elecIndex).addAnimal(animal);
            }
        }

        // 显示每个电器内的动物信息
        // Sort animals in each appliance by weight before showing
        for (Appliance appliance : elecList) {
            appliance.animals.sort(Animal::compareTo);
            appliance.showAnimals();
        }
    }
}
