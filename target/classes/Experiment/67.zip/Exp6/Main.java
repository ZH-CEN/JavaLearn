package Experiment.Exp6;

import java.util.LinkedHashMap;
import java.util.Map;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner in = new Scanner(System.in);
        ArrayList<String> connection = new ArrayList<>();
        ArrayList<String> connection1 = new ArrayList<>();
        ArrayList<String> chw = new ArrayList<>();
        readInput(in, connection, connection1, chw);

        Map<String, Map<String, Electric>> mac = new HashMap<>();
        Map<String, Electric> zhu = new LinkedHashMap<>();
        processConnections(connection, mac, zhu);

        Map<String, Map<String, Electric>> maps = new HashMap<>();
        processParallelConnections(connection1, mac, maps);

        processSwitchesAndRegulators(chw, maps, zhu);

        double rui = 220;
        double[] a = calculateResistances(maps);
        double[] b = calculateMainCircuitResistances(zhu);

        double chuanR = b[0];
        double bingR = calculateParallelResistance(a);

        double chuanV = rui * chuanR / (bingR + chuanR);
        double bingV = rui * bingR / (bingR + chuanR);

        Map<String, Electric> maso = new HashMap<>();
        calculateVoltages(zhu, maps, maso, rui, chuanR, bingR, chuanV, bingV);

        ArrayList<Electric> arraylist6 = new ArrayList<>(maso.values());
        sortAndDisplay(arraylist6);
    }

    private static void readInput(Scanner in, ArrayList<String> connection, ArrayList<String> connection1, ArrayList<String> chw) {
        String s, pop, chuanxu, bingxu;
        while (true) {
            s = in.nextLine().trim();
            if ("end".equals(s))
                break;
            if (s.startsWith("#T")) {
                Pattern pattern = Pattern.compile("#(.*):(.*)");
                Matcher matcher = pattern.matcher(s);
                while (matcher.find()) {
                    chuanxu = matcher.group(1);
                    pop = matcher.group(2);
                }
                connection.add(chuanxu + ":" + pop);
            } else if (s.startsWith("#M")) {
                Pattern pattern = Pattern.compile("#(.*):(.*)");
                Matcher matcher = pattern.matcher(s);
                while (matcher.find()) {
                    bingxu = matcher.group(1);
                    pop = matcher.group(2);
                }
                connection1.add(bingxu + " " + pop);
            } else if (s.startsWith("#K") || s.startsWith("#F") || s.startsWith("#L")) {
                Pattern pattern = Pattern.compile("#(.*)");
                Matcher matcher = pattern.matcher(s);
                while (matcher.find()) {
                    pop = matcher.group(1);
                }
                chw.add(pop);
            }
        }
    }

    private static void processConnections(ArrayList<String> connection, Map<String, Map<String, Electric>> mac, Map<String, Electric> zhu) {
        for (String z1 : connection) {
            Map<String, Electric> map1 = new LinkedHashMap<>();
            Pattern pattern = Pattern.compile("(.*):(.*)");
            Matcher matcher = pattern.matcher(z1);
            String zm = "", pop = "";
            while (matcher.find()) {
                zm = matcher.group(1);
                pop = matcher.group(2);
            }
            String[] partsl = pop.split("]");
            int vb1 = 0, vb2 = 0;
            for (String jk : partsl) {
                jk = jk.trim();
                if (jk.startsWith("[IN")) {
                    vb1 = 1;
                    String[] parts4 = jk.split(" ");
                    if (!"OUT".equals(parts4[1])) {
                        String dkey = parts4[1].split("-")[0].trim();
                        map1 = complain(dkey, parts4[1], map1);
                    }
                } else if (jk.startsWith("[VCC")) {
                    vb2 = 1;
                    String[] parts4 = jk.split(" ");
                    if (!"GND".equals(parts4[1])) {
                        String dkey = parts4[1].split("-")[0].trim();
                        map1 = complain(dkey, parts4[1], map1);
                    }
                }
            }
            if (vb1 == 1) mac.put(zm, map1);
            if (vb2 == 1) zhu.putAll(map1);
        }
    }

    private static void processParallelConnections(ArrayList<String> connection1, Map<String, Map<String, Electric>> mac, Map<String, Map<String, Electric>> maps) {
        for (String conn : connection1) {
            String k11 = conn.substring(0, 2);
            Pattern pattern = Pattern.compile("(.*)\\s\\[(.*)]");
            Matcher matcher = pattern.matcher(conn);
            String pop = "";
            while (matcher.find()) {
                pop = matcher.group(2);
            }
            String[] partsl = pop.split(" ");
            for (int yq = 0; yq < partsl.length; yq++) {
                for (Map.Entry<String, Map<String, Electric>> entry1 : mac.entrySet()) {
                    if (entry1.getKey().equals(partsl[yq])) {
                        maps.put(k11 + yq, entry1.getValue());
                    }
                }
            }
        }
    }

    private static void processSwitchesAndRegulators(ArrayList<String> chw, Map<String, Map<String, Electric>> maps, Map<String, Electric> zhu) {
        for (String sid : chw) {
            for (Map.Entry<String, Map<String, Electric>> entry : maps.entrySet()) {
                processSwitchOrRegulator(sid, entry.getValue());
            }
            for (Map.Entry<String, Electric> entry : zhu.entrySet()) {
                processSwitchOrRegulator(sid, zhu);
            }
        }
    }

    private static void processSwitchOrRegulator(String sid, Map<String, Electric> circuit) {
        if (sid.startsWith("K")) {
            String diu = sid.substring(0, 2);
            Electric electric = circuit.get(diu);
            if (electric != null) {
                electric.ofopen = "turned on".equals(electric.ofopen) ? "closed" : "turned on";
            }
        } else if (sid.startsWith("F")) {
            String diu = sid.substring(0, 2);
            String vs = sid.substring(2);
            Electric electric = circuit.get(diu);
            if (electric != null) {
                electric.regulate(vs);
            }
        } else if (sid.startsWith("L")) {
            String diu = sid.substring(0, 2);
            String vs = sid.substring(3);
            Electric electric = circuit.get(diu);
            if (electric != null) {
                electric.regulate(vs);
            }
        }
    }

    private static double[] calculateResistances(Map<String, Map<String, Electric>> maps) {
        double[] a = new double[maps.size()];
        int i = 0;
        for (Map.Entry<String, Map<String, Electric>> entry : maps.entrySet()) {
            int flag = 0;
            a[i] = 0;
            for (Map.Entry<String, Electric> entry1 : entry.getValue().entrySet()) {
                if (entry1.getKey().startsWith("K") && "turned on".equals(entry1.getValue().ofopen)) {
                    flag = 1;
                }
            }
            if (flag == 1) {
                a[i] = -1;
            } else {
                for (Map.Entry<String, Electric> entry1 : entry.getValue().entrySet()) {
                    a[i] += entry1.getValue().resistance;
                }
            }
            i++;
        }
        return a;
    }

    private static double[] calculateMainCircuitResistances(Map<String, Electric> zhu) {
        double[] b = new double[1];
        b[0] = 0;
        for (Map.Entry<String, Electric> entry : zhu.entrySet()) {
            if (entry.getKey().startsWith("K") && "turned on".equals(entry.getValue().ofopen)) {
                b[0] = 0;
                break;
            }
            b[0] += entry.getValue().resistance;
        }
        return b;
    }

    private static double calculateParallelResistance(double[] a) {
        double lpl1 = 0;
        for (double v : a) {
            if (v == 0) {
                lpl1 = 0;
                break;
            } else if (v != -1) {
                lpl1 += 1.0 / v;
            }
        }
        return lpl1 == 0 ? 0 : 1.0 / lpl1;
    }

    private static void calculateVoltages(Map<String, Electric> zhu, Map<String, Map<String, Electric>> maps, Map<String, Electric> maso, double rui, double chuanR, double bingR, double chuanV, double bingV) {
        double siop = rui;
        for (Map.Entry<String, Electric> entry : zhu.entrySet()) {
            String parts8 = entry.getKey();
            Electric elc1 = entry.getValue();
            if (parts8.startsWith("K")) {
                elc1.reshuV(rui);
                rui = elc1.shuV;
                chuanV = rui * chuanR / (bingR + chuanR);
                bingV = rui * bingR / (bingR + chuanR);
            } else if (parts8.startsWith("B")) {
                elc1.reshuV(10 * chuanV / chuanR);
            } else if (parts8.startsWith("R")) {
                elc1.reshuV(5 * chuanV / chuanR);
            } else if (parts8.startsWith("D")) {
                elc1.reshuV(20 * chuanV / chuanR);
            } else if (parts8.startsWith("A")) {
                elc1.reshuV(20 * chuanV / chuanR);
            } else if (parts8.startsWith("L")) {
                elc1.reshuV(rui);
                rui = elc1.shuV;
                chuanV = rui * chuanR / (bingR + chuanR);
                bingV = rui * bingR / (bingR + chuanR);
            } else if (parts8.startsWith("F")) {
                elc1.reshuV(rui);
                rui = elc1.shuV;
                chuanV = rui * chuanR / (bingR + chuanR);
                bingV = rui * bingR / (bingR + chuanR);
            }
            maso.put(parts8, elc1);
        }

        for (Map.Entry<String, Map<String, Electric>> entry6 : maps.entrySet()) {
            siop = bingV;
            Map<String, Electric> osp = entry6.getValue();
            for (Map.Entry<String, Electric> entry1 : osp.entrySet()) {
                String parts8 = entry1.getKey();
                Electric elc1 = entry1.getValue();
                if (parts8.startsWith("K")) {
                    elc1.reshuV(siop);
                    if ("turned on".equals(elc1.ofopen)) {
                        siop = 0;
                    }
                } else if (parts8.startsWith("B")) {
                    elc1.reshuV(10 * siop / a[i]);
                } else if (parts8.startsWith("R")) {
                    elc1.reshuV(5 * siop / a[i]);
                } else if (parts8.startsWith("D")) {
                    elc1.reshuV(20 * siop / a[i]);
                } else if (parts8.startsWith("A")) {
                    elc1.reshuV(20 * siop / a[i]);
                } else if (parts8.startsWith("L")) {
                    elc1.reshuV(siop);
                    siop = elc1.shuV;
                } else if (parts8.startsWith("F")) {
                    elc1.reshuV(siop);
                    siop = elc1.shuV;
                }
                maso.put(parts8, elc1);
            }
        }
    }

    private static void sortAndDisplay(ArrayList<Electric> arraylist6) {
        Comparator<Electric> numberComparator = new Comparator<Electric>() {
            public int compare(Electric o1, Electric o2) {
                int a = o1.fanhui();
                int b = o2.fanhui();
                int c = Integer.parseInt(o1.id);
                int d = Integer.parseInt(o2.id);
                if (a > b)
                    return -1;
                else if (a == b) {
                    return Integer.compare(c, d);
                } else
                    return 1;
            }
        };
        Collections.sort(arraylist6, numberComparator);
        for (Electric suixcs : arraylist6) {
            suixcs.display();
        }
    }

    public static Map<String, Electric> complain(String dkey, String s, Map<String, Electric> map1) {
        String jkj = String.valueOf(s.charAt(1));

        if (s.startsWith("K")) {
            Electric tric = new Kaiguan(jkj);
            tric.resistance = 0;
            map1.put(dkey, tric);
        }

        else if (s.startsWith("F")) {
            Electric tric = new Fendang(jkj);
            tric.resistance = 0;
            map1.put(dkey, tric);
        }
        
        else if (s.startsWith("L")) {
            Electric tric = new Lianxu(jkj);
            tric.resistance = 0;
            map1.put(dkey, tric);
        } 
        else if (s.startsWith("B")) {
            Electric tric = new Baichi(jkj);
            tric.resistance = 10;
            map1.put(dkey, tric);

        } else if (s.startsWith("R")) {
            Electric tric = new Riguang(jkj);
            tric.resistance = 5;
            map1.put(dkey, tric);

        } else if (s.startsWith("D")) {
            Electric tric = new Diaoshan(jkj);
            tric.resistance = 20;
            map1.put(dkey, tric);
        }
        else if (s.startsWith("A")) {
            Electric tric = new Luodi(jkj);
            tric.resistance = 20;
            map1.put(dkey, tric);
        }
        else if (s.startsWith("M")) {
            Electric tric = new Bi(jkj);
            tric.resistance = 0;
            map1.put(dkey,tric);
        }
        else if (s.startsWith("T")) {
            Electric tric = new Chuan(jkj);
            tric.resistance = 0;
            map1.put(dkey,tric);
        }
        return map1;
    }
}
